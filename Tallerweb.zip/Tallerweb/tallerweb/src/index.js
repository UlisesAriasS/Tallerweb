const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// Middleware
app.use(express.json());

// Importar los enrutadores
const productosRouter = require('./routes/productosroutes.js');

// Configurar la carpeta 'view' para servir archivos estáticos
app.use(express.static(path.join(__dirname, 'view')));

// Usar el enrutador de productos (sin prefijo)
app.use(productosRouter);

// Ruta principal para servir el archivo login.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'view', 'login.html'));
});

// Ruta para /api/servicio
app.get('/api/servicio', (req, res) => {
  res.send('servicios unach');
});


// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});