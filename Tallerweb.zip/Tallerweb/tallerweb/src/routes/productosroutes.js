const express = require('express');
const router = express.Router();

//importar el controlador
const productosController = require('../controllers/productosController');

//definir rutas
router.get('/productos', productosController.obtenerProductos);
module.exports = router;