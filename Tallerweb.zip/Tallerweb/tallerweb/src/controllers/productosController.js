exports.obtenerProductos=(req,res) => {
  const productos = (
    {id: 1, nombre: "tor", precio:10 }
  );
    res.json(productos);
  };